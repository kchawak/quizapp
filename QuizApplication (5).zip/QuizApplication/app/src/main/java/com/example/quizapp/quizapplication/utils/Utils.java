package com.example.quizapp.quizapplication.utils;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.example.quizapp.quizapplication.QuizConstants;
import com.example.quizapp.quizapplication.QuizManager;
import com.example.quizapp.quizapplication.models.Question;
import com.example.quizapp.quizapplication.models.Topic;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kchaw on 5/19/2017.
 */
public class Utils {
    private static final String TAG = Utils.class.getSimpleName();

    public static void initQuestions(Context context) {
        Log.d(TAG, "Initialize questions");
        String fileData = FileUtils.readQuestionsFile(context);
        Log.d(TAG, "File data: " + fileData);
        List<Topic> topics = parseData(fileData);
        QuizManager.getInstance().setTopics(topics);
    }

    private static List<Topic> parseData(String fileData) {
        List<Topic> topics = null;
        if (!TextUtils.isEmpty(fileData)) {
            try {
                JSONObject questions = new JSONObject(fileData);
                JSONArray topicsArray = questions.optJSONArray(QuizConstants.TOPICS);
                topics = parseTopicsArray(topicsArray);
            } catch (JSONException e) {
                Log.e(TAG, "Error while parsing questions file: " + e);
            }
        }
        return topics;
    }

    private static List<Topic> parseTopicsArray(JSONArray topicsArray) {
        List<Topic> topics = null;
        if (topicsArray != null) {
            topics = new ArrayList<>();
            for (int i = 0; i < topicsArray.length(); i++) {
                JSONObject topicJson = topicsArray.optJSONObject(i);
                Topic topic = parseTopic(topicJson);
                topics.add(topic);
            }
        }
        return topics;
    }

    private static Topic parseTopic(JSONObject topicJson) {
        Topic topic = null;
        if (topicJson != null) {
            topic = new Topic();
            String topicName = topicJson.optString(QuizConstants.TOPIC_NAME);
            topic.setTopicName(topicName);

            JSONArray questionsArray = topicJson.optJSONArray(QuizConstants.QUESTIONS);
            List<Question> questions = parseQuestionsArray(questionsArray);
            topic.setQuestions(questions);
        }
        return topic;
    }

    private static List<Question> parseQuestionsArray(JSONArray questionsArray) {
        List<Question> questions = null;
        if (questionsArray != null) {
            questions = new ArrayList<>();
            for (int i = 0; i < questionsArray.length(); i++) {
                JSONObject questionJson = questionsArray.optJSONObject(i);
                Question question = parseQuestion(questionJson);
                questions.add(question);
            }
        }
        return questions;
    }

    private static Question parseQuestion(JSONObject questionJson) {
        Question question = null;
        if (questionJson != null) {
            question = new Question();
            question.setQuestion(questionJson.optString(QuizConstants.QUESTION));
            question.setAnswer(questionJson.optString(QuizConstants.ANSWER));
            JSONArray optionGroupJson = questionJson.optJSONArray(QuizConstants.OPTION_GROUP);
            List<String> optionGroup = parseOptionGroup(optionGroupJson);
            question.setOptionGroup(optionGroup);
        }
        return question;
    }

    private static List<String> parseOptionGroup(JSONArray optionGroupJson) {
        List<String> optionGroup = null;
        if (optionGroupJson != null) {
            optionGroup = new ArrayList<>();
            for (int i = 0; i < optionGroupJson.length(); i++) {
                String option = optionGroupJson.optString(i);
                optionGroup.add(option);
            }
        }
        return optionGroup;
    }
}
