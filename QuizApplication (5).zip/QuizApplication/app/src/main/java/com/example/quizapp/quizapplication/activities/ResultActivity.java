package com.example.quizapp.quizapplication.activities;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quizapp.quizapplication.R;
import com.example.quizapp.quizapplication.models.SharedData;

/**
 * @author Kalyani Chawak
 * This activity shows the Quiz Statistics of the quiz taken
 * The values are persisted with the help of SharedPreferences
 */

public class ResultActivity extends Activity {
    private static final String TAG = ResultActivity.class.getSimpleName();

    private TextView mNoOfQuestions;
    private TextView mNoOfCorrectAnswers;
    private TextView mNoOfCheat;
    private TextView mStats;

    private int NoOfQuestions;
    private int NoOfCorrectAnswers;
    private int NoOfCheat;
    private int Stats;

    private Button mShowStats;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "Inside onCreate");
        setContentView(R.layout.results_screen);
        init();
    }

    private void init() {
        SharedData.Init(this);

        mNoOfQuestions = (TextView) findViewById(R.id.stat_tot_ques_edit);
        mNoOfCorrectAnswers = (TextView) findViewById(R.id.stat_correct_edit);
        mNoOfCheat = (TextView) findViewById(R.id.stat_cheat_edit);
        mStats = (TextView) findViewById(R.id.stat_edit);

        showResults();
    }

    private void showResults() {

        mShowStats = (Button) findViewById(R.id.result_button);
        mShowStats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Loading from SharedData class
                SharedData.LoadFromPref();
                NoOfQuestions = SharedData.GetNoOfQuestions();
                NoOfCheat = SharedData.GetNoOfCheat();
                NoOfCorrectAnswers = SharedData.GetNoOfCorrectAnswers();

                Stats = (NoOfCorrectAnswers * 100) / NoOfQuestions ;

                Log.d(TAG,"ResultActivity");

                mNoOfQuestions.setText(String.format("%d", NoOfQuestions));
                mNoOfCorrectAnswers.setText(String.format("%d", NoOfCorrectAnswers));
                mNoOfCheat.setText(String.format("%d", NoOfCheat));
                mStats.setText(String.format("%d percent", Stats));

                int messageResId = 0;
                messageResId = R.string.thanks_text;
                Toast.makeText(ResultActivity.this, messageResId, Toast.LENGTH_SHORT).show();

            }
        });

    }


}
