package com.example.quizapp.quizapplication;

/**
 * Created by kchaw on 5/19/2017.
 */

// Variable in this file must match with questions.json file
public interface QuizConstants {
    String TOPICS = "topics";
    String TOPIC_NAME = "topic_name";
    String QUESTIONS = "questions";
    String QUESTION = "question";
    String OPTION_GROUP = "option_group";
    String ANSWER = "answer";
}
