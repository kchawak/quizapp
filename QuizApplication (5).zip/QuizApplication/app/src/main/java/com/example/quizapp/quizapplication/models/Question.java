package com.example.quizapp.quizapplication.models;

import java.util.List;

/**
 * Created by kchaw on 5/19/2017.
 */
public class Question {
    private String question;
    private List<String> optionGroup;
    private String answer;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public List<String> getOptionGroup() {
        return optionGroup;
    }

    public void setOptionGroup(List<String> optionGroup) {
        this.optionGroup = optionGroup;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    @Override
    public String toString() {
        return "Question: " + question + ", Answer: " + answer;
    }
}
