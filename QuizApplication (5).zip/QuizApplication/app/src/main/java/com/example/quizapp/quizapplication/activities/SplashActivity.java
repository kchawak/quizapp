package com.example.quizapp.quizapplication.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.util.Log;

import com.example.quizapp.quizapplication.R;

/**
 * @author Kalyani Chawak
 * This activity displays the Splash Screen using Handler
 * The Splash Screen stays active for 2 sec
 */

public class SplashActivity extends Activity {
    private static final String TAG = SplashActivity.class.getSimpleName();
    private static final long SPLASH_DELAY = 2000;
    Handler mHandler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "Activity created");
        setContentView(R.layout.splash);
        mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                handleSplashFinish();
            }
        }, SPLASH_DELAY);
    }

    private void handleSplashFinish() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        Log.d(TAG, "Finishing activity");
        finish();
    }
}
