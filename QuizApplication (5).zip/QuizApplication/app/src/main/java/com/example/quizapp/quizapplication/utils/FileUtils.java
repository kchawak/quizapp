package com.example.quizapp.quizapplication.utils;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;

import com.example.quizapp.quizapplication.activities.MainActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

/**
 * Created by kchaw on 5/19/2017.
 */
public class FileUtils {
    private static final String TAG = FileUtils.class.getSimpleName();

    public static boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            Log.d(TAG, "External Storage Readable");
            return true;
        }

        return false;
    }

    public static String readQuestionsFile(Context context) {

        StringBuffer sb = new StringBuffer();
        context = context.getApplicationContext();
        try {

            File externalStorageDir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS);
            File QuizFile = new File(externalStorageDir, "quiz/questions.json");
            FileInputStream stream = new FileInputStream(QuizFile);
 //           InputStream is = context.getAssets().open("questions.json");
            BufferedReader reader = null;
            try {
                Log.d(TAG, "Read data from file");
                FileChannel fc = stream.getChannel();
                MappedByteBuffer bb = fc.map(FileChannel.MapMode.READ_ONLY, 0, fc.size());
                reader = new BufferedReader(new InputStreamReader(stream));
                String mLine;
                while ((mLine = reader.readLine()) != null) {
                    sb.append(mLine);
                }
            } catch (IOException e) {
                Log.e(TAG, "Exception while reading file: " + e);
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
}
