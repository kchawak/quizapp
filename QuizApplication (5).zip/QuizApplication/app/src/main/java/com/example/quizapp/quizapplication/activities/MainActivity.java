package com.example.quizapp.quizapplication.activities;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quizapp.quizapplication.QuizManager;
import com.example.quizapp.quizapplication.R;
import com.example.quizapp.quizapplication.models.Topic;
import com.example.quizapp.quizapplication.utils.FileUtils;
import com.example.quizapp.quizapplication.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import static com.example.quizapp.quizapplication.R.string.sorry_text;

/**
 * @author Kalyani Chawak
 * This activity displays an image and a spinner containing the
 * names of the topics of the quiz. Selection in the spinner leads to the QuizActivity
 * Also this activity checks whether the external storage is readable and asks run-time permissions.
 * If the permission is granted, then the App reads data from Download/quiz/ folder
 */

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private static final String TAG = MainActivity.class.getSimpleName();
    private Spinner mSpinner;

    static boolean isStorageReadable;

    Context context;

    static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "Activity created");
        setContentView(R.layout.activity_main);
        mSpinner = (Spinner) findViewById(R.id.topics_spinner);
        mSpinner.setOnItemSelectedListener(this);
        init();
    }

    private void init() {
        initFile();
        Log.d(TAG, "Initialize");
        initQuestions();
        initUI();
    }

    private void initFile(){

        if(ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED)

        {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE)) {

            } else {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);

                // MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }

    }

    private void initQuestions() {
        Utils.initQuestions(this);
    }

    private void initUI() {
        List<String> topicNames = getTopicNames();
        Log.d(TAG, "Topic names: " + topicNames);
        if (topicNames != null && topicNames.size() > 0) {
            ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, topicNames);
            spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            mSpinner.setAdapter(spinnerArrayAdapter);
        } else {
            TextView errorText = new TextView(this);
            errorText.setText("Error while loading quiz topics");
            setContentView(errorText);
        }
    }

    private List<String> getTopicNames() {
        List<Topic> topics = QuizManager.getInstance().getTopics();
        List<String> topicNames = null;
        if (topics != null && topics.size() > 0) {
            topicNames = new ArrayList<>();
            String defaultTextForSpinner = "Please select topic";
            topicNames.add(defaultTextForSpinner);
            for (int i = 0; i < topics.size(); i++) {
                Topic topic = topics.get(i);
                String topicName = topic.getTopicName();
                topicNames.add(topicName);
            }
        }
        return topicNames;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Log.d(TAG, "Position of selected item: " + position);
        if(position == 0) {
            Toast.makeText(this, "Please select topic", Toast.LENGTH_SHORT).show();
        } else {
            // We have set default item for spinner hence subtracting 1 from position
            int selectedTopicIndex = position - 1;
            QuizManager.getInstance().setSelectedTopicIndex(selectedTopicIndex);
            Intent intent = new Intent(this, QuizActivity.class);
            startActivity(intent);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }

    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Log.d(TAG, "In Check for storage readability loop. Permission granted");

                    isStorageReadable = FileUtils.isExternalStorageReadable();
                    if (!isStorageReadable) {
                        Log.d(TAG, "External Storage not Readable");
                        Toast.makeText(this, sorry_text, Toast.LENGTH_SHORT).show();
                    } else {

                        Log.d(TAG, "About to read JSON file");
                        FileUtils.readQuestionsFile(context);

                    }

                    // permission was granted, yay! Do the
                    //  task you need to do.

                } else {
                    Log.d(TAG, "In Check for storage readability loop. Permission denied");
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }


        }
    }
}
