package com.example.quizapp.quizapplication;

import com.example.quizapp.quizapplication.models.Topic;

import java.util.List;

/**
 * Created by kchaw on 5/19/2017.
 */

public class QuizManager {
    private static final QuizManager ourInstance = new QuizManager();
    public static final int ERROR_INDEX = -99;
    private List<Topic> topics;
    private int selectedTopicIndex = ERROR_INDEX;

    public static QuizManager getInstance() {
        return ourInstance;
    }

    private QuizManager() {
    }

    public List<Topic> getTopics() {
        return topics;
    }

    public void setTopics(List<Topic> topics) {
        this.topics = topics;
    }

    public int getSelectedTopicIndex() {
        return selectedTopicIndex;
    }

    public void setSelectedTopicIndex(int selectedTopicIndex) {
        this.selectedTopicIndex = selectedTopicIndex;
    }

}
