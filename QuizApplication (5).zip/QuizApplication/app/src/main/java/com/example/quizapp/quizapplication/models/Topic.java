package com.example.quizapp.quizapplication.models;

import java.util.List;

/**
 * Created by kchaw on 5/19/2017.
 */
public class Topic {
    private String topicName;
    private List<Question> questions;
    private List<Question> options;
    private List<Question> answer;

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Question> questions) {
        this.questions = questions;
    }

    public List<Question> getOptions() {
        return options;
    }

    public List<Question> getAnswer() {
        return answer;
    }
}
