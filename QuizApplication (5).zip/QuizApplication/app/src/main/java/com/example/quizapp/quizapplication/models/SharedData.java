package com.example.quizapp.quizapplication.models;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

/**
 * Created by kchaw on 5/18/2017.
 */

public class SharedData {

    public static final String MY_PREF = "mypref";
    public static int mNoOfQuestions = 0;
    public static int mNoOfCorrectAnswers = 0;
    public static int mNoOfCheat = 0;

    private static final String TAG = "SharedData";

    private static Context mContext;

    public static void Init(Context context)
    {
        mContext 		= context;
    }

    public static void LoadFromPref() {
        SharedPreferences settings = mContext.getSharedPreferences(MY_PREF, 0);
        mNoOfQuestions = settings.getInt("NO_OF_QUESTIONS", 0);
        mNoOfCheat = settings.getInt("NO_CHEAT", 0);
        mNoOfCorrectAnswers = settings.getInt("NO_CORRECT_ANSWERS", 0);
    }

    public static void StoreToPref() {
        // get the existing preference file
        SharedPreferences settings = mContext.getSharedPreferences(MY_PREF, 0);
        final SharedPreferences.Editor editor = settings.edit();

        editor.putInt("NO_OF_QUESTIONS", mNoOfQuestions);
        editor.putInt("NO_CHEAT", mNoOfCheat);
        editor.putInt("NO_CORRECT_ANSWERS", mNoOfCorrectAnswers);
        editor.commit();
    }

    public static void SetNoOfQuestions(int NO_OF_QUESTIONS)
    {
        mNoOfQuestions = NO_OF_QUESTIONS;
        Log.d(TAG, "SetNoOfQuestions");
    }
    public static void SetNoOfCheat(int NO_CHEAT)
    {
        mNoOfCheat = NO_CHEAT ;
        Log.d(TAG, "SetNoOfCheat");
    }
    public static void SetNoOfCorrectAnswers(int NO_CORRECT_ANSWERS)
    {
        mNoOfCorrectAnswers = NO_CORRECT_ANSWERS;
        Log.d(TAG, "SetNoOfCorrectAnswers");
    }

    public static int GetNoOfQuestions()
    {
        Log.d(TAG, "GetNoOfQuestions");
        return mNoOfQuestions ;
    }
    public static int GetNoOfCheat()
    {
        Log.d(TAG, "GetNoOfCheat");
        return mNoOfCheat ;
    }
    public static int GetNoOfCorrectAnswers()
    {
        Log.d(TAG, "GetNoOfCorrectAnswers");
        return mNoOfCorrectAnswers ;
    }

}
